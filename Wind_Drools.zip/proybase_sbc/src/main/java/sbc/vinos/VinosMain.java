package sbc.vinos;

import org.drools.core.marshalling.impl.ProtobufMessages.Agenda;
import org.kie.api.KieServices;
import org.kie.api.event.rule.DebugAgendaEventListener;
import org.kie.api.event.rule.DebugRuleRuntimeEventListener;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This is a sample file to launch a rule package from a rule source file.
 */
public class VinosMain {

    public static final void main(final String[] args) {
        // KieServices is the factory for all KIE services
        KieServices ks = KieServices.Factory.get();

        // From the kie services, a container is created from the classpath
        KieContainer kc = ks.getKieClasspathContainer();

        KieSession ksession = kc.newKieSession("VinosKS");
        loadData(ksession);

        execute(ksession);
    }

    public static void loadData(KieSession ksession) {
        try {
            File f = new File("DataBase.txt");
            Scanner s = new Scanner(f);
            ListadeVinos listVin = new ListadeVinos();
            while (s.hasNextLine()) {
                String line = s.nextLine();
                String[] splitText = line.split(" ");
                Vino vino = new Vino(splitText[0], splitText[1], splitText[2], Float.parseFloat(splitText[3]),
                        Boolean.parseBoolean(splitText[4]), Boolean.parseBoolean(splitText[5]),
                        Boolean.parseBoolean(splitText[6]), Boolean.parseBoolean(splitText[7]),
                        Boolean.parseBoolean(splitText[8]), Boolean.parseBoolean(splitText[9]),
                        Boolean.parseBoolean(splitText[10]), Boolean.parseBoolean(splitText[11]));
                listVin.lista.add(vino);
                ksession.insert(vino);
            }
        } catch (FileNotFoundException e) {
            System.out.println("El archivo no existe…");
            e.printStackTrace();
        }

    }

    public static void execute(KieSession ksession) {
        Cliente c = new Cliente();
        Vino vino = new Vino(null, null, null, 0, false, false, false, false, false, false, false, false);
        c.setVino(vino);
        ksession.insert(c);
        QueryResults results2 = ksession.getQueryResults("show vinos");
        System.out.println();
        System.out.println("========================= LISTA DE VINOS =========================");
        for (QueryResultsRow i : results2)
            System.out.println(i.get("v"));

        org.kie.api.runtime.rule.Agenda agenda = ksession.getAgenda();
        agenda.getAgendaGroup("RECOMENDACION").setFocus();
        agenda.getAgendaGroup("ESTABLECER").setFocus();
        agenda.getAgendaGroup("INICIO").setFocus();
        // and fire the rules
        ksession.fireAllRules();

        // and then dispose the session
        ksession.dispose();
    }
}
