package sbc.vinos;

import java.util.Objects;

public class Vino {
    String nombre;
    String gama;
    String color;
    float precio;
    Boolean carne;
    Boolean pescado;
    Boolean grasa;
    Boolean carne_blanca;
    Boolean queso;
    Boolean fresco;
    Boolean picante;
    Boolean dulce;

    private String descripcion;

    public Vino() {
    }

    public Vino(String nombre, String gama, String color, float precio, Boolean carne, Boolean pescado, Boolean grasa,
            Boolean carne_blanca,
            Boolean queso, Boolean fresco, Boolean picante, Boolean dulce) {
        this.nombre = nombre;
        this.gama = gama;
        this.color = color;
        this.precio = precio;
        this.carne = carne;
        this.pescado = pescado;
        this.grasa = grasa;
        this.carne_blanca = carne_blanca;
        this.queso = queso;
        this.fresco = fresco;
        this.picante = picante;
        this.dulce = dulce;
    }

    public void setDescripcion(int value) {
        this.descripcion = descripciones(value);
    }

    public void printDescripcion() {
        System.out.println(this.descripcion);
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGama() {
        return this.gama;
    }

    public void setGama(String gama) {
        this.gama = gama;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public float getPrecio() {
        return this.precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public Vino nombre(String nombre) {
        setNombre(nombre);
        return this;
    }

    public Vino gama(String gama) {
        setGama(gama);
        return this;
    }

    public Vino color(String color) {
        setColor(color);
        return this;
    }

    public Vino precio(float precio) {
        setPrecio(precio);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Vino)) {
            return false;
        }
        Vino vino = (Vino) o;
        return Objects.equals(nombre, vino.nombre) && Objects.equals(gama, vino.gama)
                && Objects.equals(color, vino.color) && precio == vino.precio;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, gama, color, precio);
    }

    public Boolean isCarne() {
        return this.carne;
    }

    public Boolean getCarne() {
        return this.carne;
    }

    public void setCarne(Boolean carne) {
        this.carne = carne;
    }

    public Boolean isPescado() {
        return this.pescado;
    }

    public Boolean getPescado() {
        return this.pescado;
    }

    public void setPescado(Boolean pescado) {
        this.pescado = pescado;
    }

    public Boolean isGrasa() {
        return this.grasa;
    }

    public Boolean getGrasa() {
        return this.grasa;
    }

    public void setGrasa(Boolean grasa) {
        this.grasa = grasa;
    }

    public Boolean isQueso() {
        return this.queso;
    }

    public Boolean getQueso() {
        return this.queso;
    }

    public void setQueso(Boolean queso) {
        this.queso = queso;
    }

    public Boolean isFresco() {
        return this.fresco;
    }

    public Boolean getFresco() {
        return this.fresco;
    }

    public void setFresco(Boolean fresco) {
        this.fresco = fresco;
    }

    public Boolean isPicante() {
        return this.picante;
    }

    public Boolean getPicante() {
        return this.picante;
    }

    public void setPicante(Boolean picante) {
        this.picante = picante;
    }

    public Boolean isDulce() {
        return this.dulce;
    }

    public Boolean getDulce() {
        return this.dulce;
    }

    public void setDulce(Boolean dulce) {
        this.dulce = dulce;
    }

    public Vino carne(Boolean carne) {
        setCarne(carne);
        return this;
    }

    public Vino pescado(Boolean pescado) {
        setPescado(pescado);
        return this;
    }

    public Vino grasa(Boolean grasa) {
        setGrasa(grasa);
        return this;
    }

    public Vino queso(Boolean queso) {
        setQueso(queso);
        return this;
    }

    public Vino fresco(Boolean fresco) {
        setFresco(fresco);
        return this;
    }

    public Vino picante(Boolean picante) {
        setPicante(picante);
        return this;
    }

    public Vino dulce(Boolean dulce) {
        setDulce(dulce);
        return this;
    }

    public Boolean isCarne_blanca() {
        return this.carne_blanca;
    }

    public Boolean getCarne_blanca() {
        return this.carne_blanca;
    }

    public void setCarne_blanca(Boolean carne_blanca) {
        this.carne_blanca = carne_blanca;
    }

    public Vino carne_blanca(Boolean carne_blanca) {
        setCarne_blanca(carne_blanca);
        return this;
    }

    @Override
    public String toString() {
        return "Vino[" +
                " nombre='" + getNombre() + "'" +
                ", gama='" + getGama() + "'" +
                ", color='" + getColor() + "'" +
                ", precio='" + getPrecio() + "'" +
                "]";
    }

    public String descripciones(int value) {
        String[] descripciones = new String[9];
        descripciones[0] = "Para las carnes rojas grasas se necesitará un buen tinto. Vinos tintos de variedades intensas, con paso por barrica y mucho cuerpo.";
        descripciones[1] = "Para las carnes rojas magras se necesitará un buen tinto. Prefieren tintos con leve paso por barricas y variedades con taninos medios o escasos.";
        descripciones[2] = "Para los pescados grasos se necesitará un buen blanco. Se entienden muy bien con blancos con prolongado paso por barrica.";
        descripciones[3] = "Para los pescados magros se necesitará un buen blanco. Combinan muy bien con vinos blancos ligeros, frescos, frutados .";
        descripciones[4] = "Para cuando se tienen quesos como comida el color del vino no es tan relevante. Lo que si tendremos en cuenta es que es un queso fresco. Por lo que Vinos muy jóvenes y frescos de notas herbáceas y florales se complementan muy bien incluso alguno espumoso";
        descripciones[5] = "Para cuando se tienen quesos como comida el color del vino no es tan relevante. Lo que si tendremos en cuenta es que es un queso maduro. Precisaremos de vinos jóvenes a exponentes con cuerpo y evolucionados.";
        descripciones[6] = "Para cuando tenemos carnes blancas de comida precisaremos una selección de nuestros mejores rosados. Es cierto que sobresale por su versatilidad, pero decidimos recomendar siempre con este tipo de platos.";
        descripciones[7] = "Para las comidas picantes es necesario tener en cuenta que es importante bajar esa sensación picantita con un vino blanco ágil, fresco, ligero, sin mucho volumen.";
        descripciones[8] = "Para comidas dulces complementar con vinos dulces, es la combinación perfecta. Por ello tenemos una seleccion de nuestros mejores cavas.";

        return descripciones[value];
    }
}
