package sbc.vinos;

public class Recomendacion {

    public void recomendacion(Cliente c) {
        System.out.println();
        System.out.println("========================= RECOMENDACION =========================");
        System.out.println();
        System.out.println("Muy buenas, " + c.nombre + ".");
        System.out.println();
        System.out.println("Dado el presupuesto = " + c.presupuesto + " la gama escogida sera " + c.vino.gama);
        System.out.println("Tambien, sabemos que va a comer " + c.plato
                + ". Por lo que el vino escogido tendra las siguientes características:");
        System.out.println();
        if (c.vino.carne_blanca == false) {
            if (c.vino.queso == false) {
                if (c.vino.carne == true || c.vino.pescado == true) {
                    if (c.vino.grasa == true)
                        System.out.println("Es graso.");
                    else {
                        System.out.println("Es magro.");
                    }
                }
            } else {
                if (c.vino.fresco == true)
                    System.out.println("Es fresco.");
                else {
                    System.out.println("Es maduro.");
                }
            }
        }
        if (c.vino.dulce == true) {
            System.out.println("Es dulce");
        } else {
            System.out.println("No es dulce");
        }
        if (c.vino.picante == true) {
            System.out.println("Es picante");
        } else {
            System.out.println("No es picante");
        }

        System.out.println();
        c.vino.printDescripcion();
        System.out.println();
        System.out.println("Por lo que, la lista de vinos recomendada es la siguiente:");

        for (int i = 0; i < ListadeVinos.lista.size(); i++) {

            Vino actual = ListadeVinos.lista.get(i);
            if (c.vino.queso == true && actual.queso == true) {
                if (c.vino.fresco == true && actual.fresco == true) {
                    if (actual.gama.equals(c.vino.gama)) {
                        System.out.println(actual);
                    }
                } else if (c.vino.fresco == false && actual.fresco == false) {
                    if (actual.gama.equals(c.vino.gama)) {
                        System.out.println(actual);
                    }
                }
            } else if (actual.color.equals(c.vino.color)
                    && actual.gama.equals(c.vino.gama)) {
                if (c.vino.carne == true && actual.carne == true) {
                    if (c.vino.grasa == true && actual.grasa == true) {
                        System.out.println(actual);
                    } else if (c.vino.grasa == false && actual.grasa == false) {
                        System.out.println(actual);
                    }
                } else if (c.vino.pescado == true && actual.pescado == true) {
                    if (c.vino.grasa == true && actual.grasa == true) {
                        System.out.println(actual);
                    } else if (c.vino.grasa == false && actual.grasa == false) {
                        System.out.println(actual);
                    }
                } else if (c.vino.carne_blanca == true && actual.carne_blanca == true) {
                    System.out.println(actual);
                } else if (c.vino.picante == true && actual.picante == true) {
                    System.out.println(actual);
                } else if (c.vino.dulce == true && actual.dulce == true) {
                    System.out.println(actual);
                }
            }
        }

    }
}
