package sbc.vinos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Pregunta {
    public String solicitarNombre() throws IOException {
        System.out.println("Muy Buenas, por favor ingrese su nombre:");
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));
        String name = reader.readLine();
        return name;
    }

    public Integer solicitarEdad(String nom) throws IOException {
        int age = 0;
        while (age == 0) {
            System.out.println("Hola " + nom + ", indique su edad:");
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(System.in));
            String ed = reader.readLine();
            if (!isNumeric(ed)) {
                System.out.println("ERROR: La edad introducida no es un numero");
            } else if (Integer.parseInt(ed) < 18)
                System.out.println("ERROR: La edad introducida no es superior a la mayoria de edad");
            else
                age = Integer.parseInt(ed);
        }
        return age;
    }

    public String solicitarPlato() throws IOException {
        String pl = null;
        Boolean control = true;
        while (control) {
            System.out.println(
                    "Un vez introducidos sus datos personales, nos gustaria que introdujera el plato que va a comer.");
            System.out.println(
                    "carne roja || pescado || carne blanca || queso || otro :");
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(System.in));
            pl = reader.readLine();
            if (pl.equals("carne roja") || pl.equals("carne blanca") || pl.equals("pescado") || pl.equals("queso")
                    || pl.equals("otro")) {
                control = false;
            } else {
                System.out.println("ERROR: No ha seleccionado ninguna opcion propuesta");
            }
        }
        return pl;
    }

    public Boolean preguntarPlato(Cliente c) throws IOException {

        System.out.println("Sabemos que como comida vas a comer " + c.plato + ".");
        if (c.plato.equals("carne roja") || c.plato.equals("pescado")) {
            System.out.println("Necesitamos saber si es graso(1) o magro(2):");
        } else if (c.plato.equals("queso")) {
            System.out.println("Necesitamos saber si es fresco(1) o maduro(2):");
        } else if (c.plato.equals("otro")) {
            System.out.println("Necesitamos saber si la comida es picante(1) o dulce(2):");
        } else {
            return false;
        }
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));
        String pl = reader.readLine();
        if (pl.equals("1")) {
            return true;
        } else {
            return false;
        }
    }

    public Integer solicitarPresupuesto() throws IOException {
        int pre = 0;
        while (pre == 0) {
            System.out.println("Por ultimo, sera necesario que introduzca su presupuesto:");
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(System.in));
            String p = reader.readLine();
            if (!isNumeric(p)) {
                System.out.println("ERROR: El presupuesto introducido no es un numero");
            } else if (Integer.parseInt(p) < 1)
                System.out.println("ERROR: No puede escoger un vino si no tiene presupuesto");
            else
                pre = Integer.parseInt(p);
        }
        return pre;
    }

    private static boolean isNumeric(String cadena) {
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }
}
