package sbc.vinos;

import java.util.Objects;
import sbc.vinos.Vino;

public class Cliente {
    String nombre = null;
    int edad = 0;
    String plato = null;
    int presupuesto = 0;
    Vino vino;
    boolean preparado = false;

    public Cliente() {
    }

    public Cliente(String nombre, Integer edad, String plato, Integer presupuesto) {
        this.nombre = nombre;
        this.edad = edad;
        this.plato = plato;
        this.presupuesto = presupuesto;
    }

    public boolean getPreparado() {
        return this.preparado;
    }

    public void setPreparado(boolean preparado) {
        this.preparado = preparado;
    }

    public void setVino(Vino vino) {
        this.vino = vino;
    }

    public Integer getEdad() {
        return this.edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public Cliente edad(Integer edad) {
        setEdad(edad);
        return this;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPlato() {
        return this.plato;
    }

    public void setPlato(String plato) {
        this.plato = plato;
    }

    public Integer getPresupuesto() {
        return this.presupuesto;
    }

    public void setPresupuesto(Integer presupuesto) {
        this.presupuesto = presupuesto;
    }

    public Cliente nombre(String nombre) {
        setNombre(nombre);
        return this;
    }

    public Cliente plato(String plato) {
        setPlato(plato);
        return this;
    }

    public Cliente presupuesto(Integer presupuesto) {
        setPresupuesto(presupuesto);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Cliente)) {
            return false;
        }
        Cliente cliente = (Cliente) o;
        return Objects.equals(nombre, cliente.nombre) && Objects.equals(plato, cliente.plato)
                && Objects.equals(presupuesto, cliente.presupuesto);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, plato, presupuesto);
    }

    @Override
    public String toString() {
        return "{" +
                " nombre='" + getNombre() + "'" +
                ", plato='" + getPlato() + "'" +
                ", presupuesto='" + getPresupuesto() + "'" +
                "}";
    }

    public void establecerGama() {
        if (this.presupuesto <= 7) {
            this.vino.gama = "baja";
        } else if (this.presupuesto > 7 && this.presupuesto < 15) {
            this.vino.gama = "media";
        } else {
            this.vino.gama = "alta";
        }
    }

    public void establecerColorytipo(Cliente c, Boolean bool) {
        if (this.plato.equals("carne roja")) {
            this.vino.color = "tinto";
            this.vino.carne = true;
            this.vino.grasa = bool;
            if (bool == true) {
                this.vino.setDescripcion(0);
            } else {
                this.vino.setDescripcion(1);
            }
        } else if (this.plato.equals("pescado")) {
            this.vino.color = "blanco";
            this.vino.pescado = true;
            this.vino.grasa = bool;
            if (bool == true) {
                this.vino.setDescripcion(2);
            } else {
                this.vino.setDescripcion(3);
            }
        } else if (this.plato.equals("queso")) {
            this.vino.queso = true;
            this.vino.fresco = bool;
            if (bool == true) {
                this.vino.setDescripcion(4);
            } else {
                this.vino.setDescripcion(5);
            }
        } else if (this.plato.equals("carne blanca")) {
            this.vino.color = "rosado";
            this.vino.carne_blanca = true;
            this.vino.setDescripcion(6);
        } else if (this.plato.equals("otro")) {
            if (bool == true) {
                this.vino.color = "blanco";
                this.vino.picante = true;
                this.vino.setDescripcion(7);
            } else {
                this.vino.color = "cava";
                this.vino.dulce = true;
                this.vino.setDescripcion(8);
            }
        }
    }
}
