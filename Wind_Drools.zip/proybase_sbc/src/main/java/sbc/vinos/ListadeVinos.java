package sbc.vinos;

import java.util.ArrayList;
import java.util.Objects;

public class ListadeVinos {
    static ArrayList<Vino> lista = new ArrayList();

    public ListadeVinos() {
    }

    public ListadeVinos(ArrayList<Vino> lista) {
        this.lista = lista;
    }

    public ArrayList<Vino> getLista() {
        return this.lista;
    }

    public void setLista(ArrayList<Vino> lista) {
        this.lista = lista;
    }

    public ListadeVinos lista(ArrayList<Vino> lista) {
        setLista(lista);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof ListadeVinos)) {
            return false;
        }
        ListadeVinos listadeVinos = (ListadeVinos) o;
        return Objects.equals(lista, listadeVinos.lista);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(lista);
    }

    @Override
    public String toString() {
        return "{" +
            " lista='" + getLista() + "'" +
            "}";
    }
}
